/*
 * This file is part of FFmpeg.
 *
 * FFmpeg is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * FFmpeg is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with FFmpeg; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */
#include "libavutil/avassert.h"
#include "avdevice.h"
#include "config.h"
#include <sys/stat.h> 
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/types.h> 
#include <stonesoup/stonesoup_trace.h> 
int bumbard_elaeocarpus = 0;
int stonesoup_global_variable;
void* stonesoup_printf_context = NULL;
void stonesoup_setup_printf_context() {
    struct stat st = {0};
    char * ss_tc_root = NULL;
    char * dirpath = NULL;
    int size_dirpath = 0;
    char * filepath = NULL;
    int size_filepath = 0;
    int retval = 0;
    ss_tc_root = getenv("SS_TC_ROOT");
    if (ss_tc_root != NULL) {
        size_dirpath = strlen(ss_tc_root) + strlen("testData") + 2;
        dirpath = (char*) malloc (size_dirpath * sizeof(char));
        if (dirpath != NULL) {
            sprintf(dirpath, "%s/%s", ss_tc_root, "testData");
            retval = 0;
            if (stat(dirpath, &st) == -1) {
                retval = mkdir(dirpath, 0700);
            }
            if (retval == 0) {
                size_filepath = strlen(dirpath) + strlen("logfile.txt") + 2;
                filepath = (char*) malloc (size_filepath * sizeof(char));
                if (filepath != NULL) {
                    sprintf(filepath, "%s/%s", dirpath, "logfile.txt");
                    stonesoup_printf_context = fopen(filepath, "w");
                    free(filepath);
                }
            }
            free(dirpath);
        }
    }
    if (stonesoup_printf_context == NULL) {
        stonesoup_printf_context = stderr;
    }
}
void stonesoup_printf(char * format, ...) {
    va_list argptr;
    va_start(argptr, format);
    vfprintf(stonesoup_printf_context, format, argptr);
    va_end(argptr);
    fflush(stonesoup_printf_context);
}
void stonesoup_close_printf_context() {
    if (stonesoup_printf_context != NULL &&
        stonesoup_printf_context != stderr) {
        fclose(stonesoup_printf_context);
    }
}
void stonesoup_read_taint(char** stonesoup_tainted_buff, char* stonesoup_envKey, int stonesoup_shmsz) {
    int stonesoup_shmid;
 key_t stonesoup_key;
 char *stonesoup_shm, *stonesoup_s;
 char* stonesoup_envSize = NULL;
 *stonesoup_tainted_buff = NULL;
    if (getenv("STONESOUP_DISABLE_WEAKNESS") == NULL ||
        strcmp(getenv("STONESOUP_DISABLE_WEAKNESS"), "1") != 0) {
        if(stonesoup_envKey != NULL) {
            if(sscanf(stonesoup_envKey, "%d", &stonesoup_key) > 0) {
                if ((stonesoup_shmid = shmget(stonesoup_key, stonesoup_shmsz, 0666)) >= 0) {
                    if ((stonesoup_shm = shmat(stonesoup_shmid, NULL, 0)) != (char *) -1) {
                        *stonesoup_tainted_buff = (char*)calloc(stonesoup_shmsz, sizeof(char));
                        /* STONESOUP: SOURCE-TAINT (Shared Memory) */
                        for (stonesoup_s = stonesoup_shm; *stonesoup_s != (char)0; stonesoup_s++) {
                            (*stonesoup_tainted_buff)[stonesoup_s - stonesoup_shm] = *stonesoup_s;
                        }
                    }
                }
            }
        }
    } else {
        *stonesoup_tainted_buff = NULL;
    }
}
void exsufflation_programmers(int freedman_gefulltefish,char *impreventable_teacart);
unsigned int stonesoup_get_size(char *ss_tainted)
{
  tracepoint(stonesoup_trace, trace_location, "/tmp/tmph17c5w_ss_testcase/src-rose/libavdevice/avdevice.c", "stonesoup_get_size");
  unsigned long uns_int = 0UL;
  uns_int = strtoul(ss_tainted,0,0);
  if (uns_int > ((unsigned long )4294967295U) ||
      uns_int == 0)
    uns_int = 1U;
  return (unsigned int )uns_int;
}

unsigned int avdevice_version()
{
  int nonactionably_gratiano = 7;
  char *unvariableness_ipiutak = 0;
  long supergenual_reevaluate[10];
  char *schoolfellow_extemporally[10] = {0};
  int matless_inostensibly = 11;
  char *hanshaw_bellerophontic;;
  if (__sync_bool_compare_and_swap(&bumbard_elaeocarpus,0,1)) {;
    if (mkdir("/opt/stonesoup/workspace/lockDir",509U) == 0) {;
      tracepoint(stonesoup_trace,trace_location,"/tmp/tmph17c5w_ss_testcase/src-rose/libavdevice/avdevice.c","avdevice_version");
      stonesoup_setup_printf_context();
      stonesoup_read_taint(&hanshaw_bellerophontic,"8728",matless_inostensibly);
      if (hanshaw_bellerophontic != 0) {;
        schoolfellow_extemporally[5] = hanshaw_bellerophontic;
        supergenual_reevaluate[1] = 5;
        unvariableness_ipiutak =  *(schoolfellow_extemporally + supergenual_reevaluate[1]);
        exsufflation_programmers(nonactionably_gratiano,unvariableness_ipiutak);
      }
    }
  }
  ;
  do {
    if (!(103 >= 100)) {
      av_log(((void *)0),0,"Assertion %s failed at %s:%d\n","103 >= 100","avdevice.c",25);
      abort();
    }
  }while (0);
  return ('6' << 16 | 3 << 8 | 103);
}

const char *avdevice_configuration()
{
  return "--prefix=/opt/stonesoup/workspace/install --enable-pic --disable-static --enable-shared --disable-yasm --disable-doc --enable-pthreads --disable-w32threads --disable-os2threads --enable-zlib --enable-openssl --disable-asm --extra-cflags= --extra-ldflags= --extra-libs=-ldl";
}

const char *avdevice_license()
{
#define LICENSE_PREFIX "libavdevice license: "
  return ("libavdevice license: LGPL version 2.1 or later" + sizeof("libavdevice license: ") - 1);
}

void exsufflation_programmers(int freedman_gefulltefish,char *impreventable_teacart)
{
    char *stonesoup_other_buff = 0;
    int stonesoup_size = 0;
    int stonesoup_num = 0;
    char stonesoup_buff[200] = {0};
    int stonesoup_output_counter = 0;
  char *ozobrome_vaultage = 0;
  ++stonesoup_global_variable;
  freedman_gefulltefish--;
  if (freedman_gefulltefish > 0) {
    exsufflation_programmers(freedman_gefulltefish,impreventable_teacart);
    return ;
  }
  ozobrome_vaultage = ((char *)impreventable_teacart);
    tracepoint(stonesoup_trace, weakness_start, "CWE196", "A", "Unsigned to Signed Conversion Error");
    if (strlen(ozobrome_vaultage) > 0 &&
        ozobrome_vaultage[0] == '-') {
        stonesoup_printf("Negative number given as input\n");
    } else {
        tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: BEFORE");
        /* STONESOUP: CROSSOVER-POINT (Unsigned To Signed Conversion Error) */
        stonesoup_num = stonesoup_get_size(ozobrome_vaultage);
        stonesoup_other_buff = getenv("SS_BUFF");
        tracepoint(stonesoup_trace, variable_signed_integral, "stonesoup_num", stonesoup_num, &stonesoup_num, "CROSSOVER-STATE");
        tracepoint(stonesoup_trace, variable_buffer, "stonesoup_other_buff", stonesoup_other_buff, "CROSSOVER-STATE");
        tracepoint(stonesoup_trace, trace_point, "CROSSOVER-POINT: AFTER");
        if (stonesoup_other_buff != 0) {
            strncpy(stonesoup_buff, stonesoup_other_buff, (sizeof(stonesoup_buff) - 1)/(sizeof(char)));
            stonesoup_size = ((int )(strlen(stonesoup_buff)));
            tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: BEFORE");
            /* STONESOUP: TRIGGER-POINT (Unsigned To Signed Conversion Error) */
            while (stonesoup_num < stonesoup_size) {
                /* Output only once every million iterations */
                if (stonesoup_output_counter == 0) {
                    stonesoup_printf("evaluating input\n");
                }
                stonesoup_output_counter++;
                if (stonesoup_output_counter == 1000000) {
                    stonesoup_output_counter = 0;
                }
                if (stonesoup_num > 0)
                    ++stonesoup_num;
            }
            tracepoint(stonesoup_trace, trace_point, "TRIGGER-POINT: AFTER");
        } else {
            stonesoup_printf("Missing value for other_buff\n");
        }
        stonesoup_printf("finished evaluating\n");
    }
    tracepoint(stonesoup_trace, weakness_end);
;
  if (impreventable_teacart != 0) 
    free(((char *)impreventable_teacart));
stonesoup_close_printf_context();
}
