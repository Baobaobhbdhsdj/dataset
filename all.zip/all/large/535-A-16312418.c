#include<stdio.h>
int main(int argc, char *argv[])
{
    int n;
    while(scanf("%d",&n)==1)
    {
        if(n==0)
            printf("zero\n");
        else if(n==1)
            printf("one\n");
        else if(n==2)
            printf("two\n");
        else if(n==3)
            printf("three\n");
        else if(n==4)
            printf("four\n");
        else if(n==5)
            printf("five\n");
        else if(n==6)
            printf("six\n");
        else if(n==7)
            printf("seven\n");
        else if(n==8)
            printf("eight\n");
        else if(n==9)
            printf("nine\n");
        else if(n==10)
            printf("ten\n");
        else if(n==11)
            printf("eleven\n");
        else if(n==12)
            printf("twelve\n");
        else if(n==13)
            printf("thirten\n");
        else if(n==14)
            printf("fourteen\n");
        else if(n==15)
            printf("fifteen\n");
        else if(n==16)
            printf("sixteen\n");
        else if(n==17)
            printf("seventeen\n");
        else if(n==18)
            printf("eighteen\n");
        else if(n==19)
            printf("nineteen\n");
        else if(n==20)
            printf("twenty\n");
        else if(n==21)
            printf("twenty-one\n");
        else if(n==22)
            printf("twenty-two\n");
        else if(n==23)
            printf("twenty-three\n");
        else if(n==24)
            printf("twenty-four\n");
        else if(n==25)
            printf("twenty-five\n");
        else if(n==26)
            printf("twenty-six\n");
        else if(n==27)
            printf("twenty-seven\n");
        else if(n==28)
            printf("twenty-eight\n");
        else if(n==29)
            printf("twenty-nine\n");
        else if(n==30)
            printf("thirty\n");
        else if(n==31)
            printf("thirty-one\n");
        else if(n==32)
            printf("thirty-two\n");
        else if(n==33)
            printf("thirty-three\n");
        else if(n==34)
            printf("thirty-four\n");
        else if(n==35)
            printf("thirty-five\n");
        else if(n==36)
            printf("thirty-six\n");
        else if(n==37)
            printf("thirty-seven\n");
        else if(n==38)
            printf("thirty-eight\n");
        else if(n==39)
            printf("thirty-nine\n");
        else if(n==40)
            printf("forty\n");
       else if(n==41)
            printf("forty-one\n");
        else if(n==42)
            printf("forty-two\n");
        else if(n==43)
            printf("forty-three\n");
        else if(n==44)
            printf("forty-four\n");
        else if(n==45)
            printf("forty-five\n");
        else if(n==46)
            printf("forty-six\n");
        else if(n==47)
            printf("forty-seven\n");
        else if(n==48)
            printf("forty-eight\n");
        else if(n==49)
            printf("forty-nine\n");
        else if(n==50)
            printf("fifty\n");
        else if(n==51)
            printf("fifty-one\n");
        else if(n==52)
            printf("fifty-two\n");
        else if(n==53)
            printf("fifty-three\n");
        else if(n==54)
            printf("fifty-four\n");
        else if(n==55)
            printf("fifty-five\n");
        else if(n==56)
            printf("fifty-six\n");
        else if(n==57)
            printf("fifty-seven\n");
        else if(n==58)
            printf("fifty-eight\n");
        else if(n==59)
            printf("fifty-nine\n");
        else if(n==60)
            printf("sixty\n");
        else if(n==61)
            printf("sixty-one\n");
        else if(n==62)
            printf("sixty-two\n");
        else if(n==63)
            printf("sixty-three\n");
        else if(n==64)
            printf("sixty-four\n");
        else if(n==65)
            printf("sixty-five\n");
        else if(n==66)
            printf("sixty-six\n");
        else if(n==67)
            printf("sixty-seven\n");
        else if(n==68)
            printf("sixty-eight\n");
        else if(n==69)
            printf("sixty-nine\n");
        else if(n==70)
            printf("seventy\n");
       else if(n==71)
            printf("seventy-one\n");
        else if(n==72)
            printf("seventy-two\n");
        else if(n==73)
            printf("seventy-three\n");
        else if(n==74)
            printf("seventy-four\n");
        else if(n==75)
            printf("seventy-five\n");
        else if(n==76)
            printf("seventy-six\n");
        else if(n==77)
            printf("seventy-seven\n");
        else if(n==78)
            printf("seventy-eight\n");
        else if(n==79)
            printf("seventy-nine\n");
        else if(n==80)
            printf("eighty\n");
        else if(n==81)
            printf("eighty-one\n");
        else if(n==82)
            printf("eighty-two\n");
        else if(n==83)
            printf("eighty-three\n");
        else if(n==84)
            printf("eighty-four\n");
        else if(n==85)
            printf("eighty-five\n");
        else if(n==86)
            printf("eighty-six\n");
        else if(n==87)
            printf("eighty-seven\n");
        else if(n==88)
            printf("eighty-eight\n");
        else if(n==89)
            printf("eighty-nine\n");
        else if(n==90)
            printf("ninety\n");
         else if(n==91)
            printf("ninety-one\n");
        else if(n==92)
            printf("ninety-two\n");
        else if(n==93)
            printf("ninety-three\n");
        else if(n==94)
            printf("ninety-four\n");
        else if(n==95)
            printf("ninety-five\n");
        else if(n==96)
            printf("ninety-six\n");
        else if(n==97)
            printf("ninety-seven\n");
        else if(n==98)
            printf("ninety-eight\n");
        else if(n==99)
            printf("ninety-nine\n");

    }
    return 0;
}
